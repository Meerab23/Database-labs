//#include<iostream>
//#include<fstream>
//#include<string>
//using namespace std;
//int main()
//{
//	ifstream fin;
//	ofstream fout;
//	string regNo, Firstname, Lastname, Program;
//	double CGPA;
//	string contact;
//	char trash;
//	fout.open("studentinfo.csv");
//	if (fout.is_open())
//	{
//
//		fout << "L1f11BSCS0001,Sadia,Khan,BSCS,3.27,03321234123\n";
//		fout << "L1f11BSCS0021,Shanya,Khan,BSCS,3.77,03321234213\n";
//		fout << "L1f11BSCS0031,Goree,Khan,BSCS,3.17,03321234143\n";
//		fout << "L1f11BSCS0041,Jemayma,Khan,BSCS,3.85,03321234223\n";
//		fout << "L1f11BSCS0022,Samandar,Khan,BSCS,3.97,03321234542\n";
//		fout.close();
//	}
//	else
//	{
//		cout << "NO file";
//	}
//		fin.open("studentinfo.csv");
//		if (fin.is_open())
//		{
//			while (!fin.eof())
//			{
//				getline(fin, regNo, ',');
//				getline(fin, Firstname, ',');
//				getline(fin, Lastname, ',');
//				getline(fin, Program, ',');
//				fin >> CGPA;
//				fin >> trash;
//				getline(fin, contact, '\n');
//				if (CGPA >= 2.5&&CGPA <= 3.5)
//				{
//					cout << Firstname<<endl;
//				}
//			}
//		}
//	else
//	{
//		cout << "Cannot open";
//	}
//	system("pause");
//	return 0;
//}