//#include<iostream>
//#include<fstream>
//#include<string>
//using namespace std;
//int main()
//{
//	ofstream fout;
//	fout.open("studentinfo.csv");
//	string regNo, Firstname, Lastname, Program;
//	double CGPA;
//	int contact;
//
//	if (fout.is_open())
//	{
//		for (int i = 0; i < 3; i++)
//		{
//			cout << "Enter registration number: " << endl;
//			cin >> regNo;
//			cout << "Enter first name: " << endl;
//			cin >> Firstname;
//			cout << "Enter last name: " << endl;
//			cin >> Lastname;
//			cout << "Enter program: " << endl;
//			cin >> Program;
//			cout << "Enter CGPA: " << endl;
//			cin >> CGPA;
//			cout << "Enter contact number: " << endl;
//			cin >> contact;
//			fout << regNo << "," << Firstname << "," << Lastname << "," << Program << "," << CGPA << "," << contact;
//		}
//		
//	}
//	system("pause");
//	return 0;
//}