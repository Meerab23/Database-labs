#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main()
{
	string deptname, fname, lname, date, phone, status;
	int deptid, empid, salary, deptid1;
	char trash;
	ifstream fin1, fin2;
	fin1.open("department.csv");
	fin2.open("employee.csv");
	if (fin1.is_open() && fin2.is_open())
	{
		while (!fin1.eof())
		{
			fin1 >> deptid;
			fin1 >> trash;
			getline(fin1, deptname, '\n');
			if (deptname == "Sales")
			{
				fin1.close();
				break;
			}
		}

		while (!fin2.eof())
		{
			fin2 >> empid;
			fin2 >> trash;
			getline(fin2, fname, ',');
			getline(fin2, lname, ',');
			getline(fin2, date, ',');
			fin2 >> deptid1;
			fin2 >> trash;
			getline(fin2, phone, ',');
			fin2 >> salary;
			fin2 >> trash;
			getline(fin2, status, '\n');
			if (salary>=81000)
			{
				cout << fname << "" << lname << salary << endl;
			}
		}
	}
	system("pause");
	return 0;
}