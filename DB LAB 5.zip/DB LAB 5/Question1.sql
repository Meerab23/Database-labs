-- create database Task1;
create table Book(
	isbn int primary key,
    book_title varchar(30),
    book_price int,
    genre varchar(30)
);
create table Publisher(
	publisher_name varchar(30),
    publisher_id int primary key,
    contact int
);
create table Author(
	author_id int primary key,
    author_name varchar(30),
    email varchar(30),
    contact int,
    address varchar(30)
);
create table author_book(
	isbn int,
    author_id int,
    foreign key (isbn) references Book(isbn),
    foreign key (author_id) references Author(author_id)
    
);
create table Customer(
	customer_id int primary key,
    customer_name varchar(20),
    customer_email varchar(20),
    customer_contact int,
    shipping_address varchar(20)
);

create table Orders(
	order_id int primary key,
    total_amount int,
    shipping_address varchar(30),
    isbn int,
	foreign key (isbn) references Book(isbn)
);

create table customer_order(
	order_id int,
    customer_id int,
    foreign key (order_id) references Orders(order_id),
    foreign key (customer_id) references Customer(customer_id)
);
create table staff_member(
	staff_id int primary key,
    staff_name varchar(20),
    position varchar(20),
    assigned_dept varchar(20),
    order_id int,
    customer_id int,
     foreign key (order_id) references Orders(order_id),
     foreign key (customer_id) references Customer(customer_id)
);
create table review(
	review_id int primary key,
    comments varchar(30),
    ratings int,
    customer_id int,
    foreign key (customer_id) references Customer(customer_id)
);

