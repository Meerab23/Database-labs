-- create database Question2;
create table user_details
(
   userid INT primary key,
  username VARCHAR(100),
 phone_number INT,
 email VARCHAR(100),
  dateofbirth int
);
CREATE TABLE orders (
 orderid INT primary key,
 date INT,
 amount int,
 delivery_address VARCHAR(100)
);
create table seller
(
   sellerid int primary key, 
   seller_name VARCHAR(100),
   contect_detail int
);
create table product
(
   productid int primary key,
   product_name VARCHAR(100),
   description VARCHAR(100),
   price int,
   category VARCHAR(100),
   quantity int,
   brand VARCHAR(100)
);
create table Shopping_cart
(
   cartid int primary key,
   products char(50),
   quantity int,
   total_amount int
);
create table Review(
 ReviewID int primary key,
    comment VARCHAR(100),
    Ratings int
);
create table user_order
(
 userid INT ,
 orderid INT,
 foreign key (userid) references user_details(userid),
 foreign key (orderid) references orders(orderid)
);
create table product_order
(
 orderid INT,
 productid int,
 foreign key (productid) references product(productid),
foreign key (orderid) references orders(orderid)
);
create table order_seller
(
orderid INT,
sellerid int,
foreign key (sellerid) references seller(sellerid),
foreign key (orderid) references orders(orderid)
);
create table shoppingcart_product
(
cartid int,
 foreign key (cartid) references Shopping_cart(cartid),
productid int,
 foreign key (productid) references product(productid)
);
create table user_reviews
(
userid INT ,
 foreign key (userid) references user_details(userid),
ReviewID int,
foreign key (ReviewID) references Review(ReviewID)
);
